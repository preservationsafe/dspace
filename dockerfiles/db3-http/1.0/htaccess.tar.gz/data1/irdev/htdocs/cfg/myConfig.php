<?php


### DB_READ_ONLY disables the admin console
#define ( 'DB_READ_ONLY', true ) ;
define ( 'DB_READ_ONLY', false ) ;

### MAINTENANCE_MODE redirects all requests to maintenance.html
#define ( 'MAINTENANCE_MODE', true ) ;

define( 'SHOW_DEBUG', true ) ;
#define( 'SHOW_DEVINFO', true ) ;
define( 'VERSION_LEVEL', 'development' ) ;
define( 'EMAIL_TEST_MODE', true ) ;

ini_set( 'include_path', ini_get( 'include_path' ) . ":./lib" ) ;


define( 'RAP_DB_NAME', "dev_uairrapmodel" ) ;
define( 'DEFAULT_RAP_MODEL', 'http://digitalcommons.library.arizona.edu/' ) ;
#define( 'RAP_DB_HOST', "db2.library.arizona.edu" ) ;
if( DB_READ_ONLY ) {
	define( 'RAP_DB_USER', "rouairuser" ) ;
	define( 'RAP_DB_PASS', "tF1wuy%WNO" ) ;
	define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@localhost/dev_uairbackoffice' ) ;
	#define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@db1.library.arizona.edu/dev_uairbackoffice' ) ;
} else {
	define( 'RAP_DB_USER', "irrapuser" ) ;
	define( 'RAP_DB_PASS', "RdfiaTsnk@(" ) ;
	define( 'APPLICATION_DSN', 'mysql://uairuser:tF1wuy%WNO@localhost/dev_uairbackoffice' ) ;
	#define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@db2.library.arizona.edu/dev_uairbackoffice' ) ;
}


if( !defined( 'APPLICATION_PROTOCOL' )) {
	if( !empty( $_SERVER['HTTPS'] )) { define( 'APPLICATION_PROTOCOL', 'https' ) ; }
	else { define( 'APPLICATION_PROTOCOL', 'http' ) ; }
}

define( 'USE_CLEAN_URLS', true ) ;
if( USE_CLEAN_URLS ) {
	define( 'APPLICATION_BASE_HREF', APPLICATION_PROTOCOL.'://'.$_SERVER['SERVER_NAME'].'/' ) ;
	define( 'APPLICATION_INDEX_URI', '' ) ;
	define( 'APPLICATION_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/util/login' ) ;
	define( 'ADMIN_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/adminconsole/util/login' ) ;
} else {
	define( 'APPLICATION_BASE_HREF', APPLICATION_PROTOCOL.'://'.$_SERVER['SERVER_NAME'].'/index.php' ) ;
	define( 'APPLICATION_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/index.php/util/login' ) ;
	define( 'ADMIN_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/index.php/adminconsole/util/login' ) ;
}

@include_once( 'recaptchalib.php' ) ;
define( 'RECAPTCHA_PUBLIC_KEY',  '6LezcAMAAAAAAARGtSNIgDZNy9N5xF7EUrPSiLeJ' ) ;
define( 'RECAPTCHA_PRIVATE_KEY', '6LezcAMAAAAAAGYNVdn4ioiC4OGMQl5aGTHxTcPw' ) ;


?>
