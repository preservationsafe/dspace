<?php

### DB_READ_ONLY disables the admin console
define ( 'DB_READ_ONLY', false ) ;
#define ( 'DB_READ_ONLY', true ) ;


### MAINTENANCE_MODE (true) redirects all requests to maintenance.html
#define ( 'MAINTENANCE_MODE', true ) ;


### SHOW_DEBUG (true) echos various debug info to the bottom of 
### the page and shouldn't ordinarily be used for production
define( 'SHOW_DEBUG', false ) ;










ini_set( 'include_path', ini_get( 'include_path' ) . ":./lib" ) ;

define( 'VERSION_LEVEL', 'prototype' ) ;
define( 'APPLICATION_BASE_DIR', '/data1/irproto/htdocs/' ) ;
define( 'RDFAPI_INCLUDE_DIR', "./lib/rdfapi-php/api/" ) ;

define( 'RAP_DB_NAME', "proto_irrapmodel" ) ;
define( 'DEFAULT_RAP_MODEL', 'http://digitalcommons.library.arizona.edu/' ) ;
#define( 'RAP_DB_HOST', "db2.library.arizona.edu" ) ;
if( DB_READ_ONLY ) {
	define( 'RAP_DB_USER', "rouairuser" ) ;
	define( 'RAP_DB_PASS', "tF1wuy%WNO" ) ;
	define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@localhost/proto_irbackoffice' ) ;
	#define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@db2.library.arizona.edu/proto_irbackoffice' ) ;
} else {
	define( 'RAP_DB_USER', "irrapuser" ) ;
	define( 'RAP_DB_PASS', "RdfiaTsnk@(" ) ;
	define( 'APPLICATION_DSN', 'mysql://uairuser:tF1wuy%WNO@localhost/proto_irbackoffice' ) ;
	#define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@db2.library.arizona.edu/proto_irbackoffice' ) ;
}





if( !defined( 'APPLICATION_PROTOCOL' )) {
	if( !empty( $_SERVER['HTTPS'] )) { define( 'APPLICATION_PROTOCOL', 'https' ) ; }
	else { define( 'APPLICATION_PROTOCOL', 'http' ) ; }
}

define( 'USE_CLEAN_URLS', true ) ;
if( USE_CLEAN_URLS ) {
	define( 'APPLICATION_BASE_HREF', APPLICATION_PROTOCOL.'://'.$_SERVER['SERVER_NAME'].'/' ) ;
	define( 'APPLICATION_INDEX_URI', '' ) ;
	define( 'APPLICATION_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/util/login' ) ;
	define( 'ADMIN_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/adminconsole/util/login' ) ;
} else {
	define( 'APPLICATION_BASE_HREF', APPLICATION_PROTOCOL.'://'.$_SERVER['SERVER_NAME'].'/index.php' ) ;
	define( 'APPLICATION_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/index.php/util/login' ) ;
	define( 'ADMIN_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/index.php/adminconsole/util/login' ) ;
}

@include_once( 'recaptchalib.php' ) ;
define( 'RECAPTCHA_PUBLIC_KEY',  '6LeycAMAAAAAADdkv8-WXV6Y_Dw4hkq7KAwAqr9j' ) ;
define( 'RECAPTCHA_PRIVATE_KEY', '6LeycAMAAAAAAHfzIBW-K2X0WdMGgDs-mjwsTzWq' ) ;

?>
