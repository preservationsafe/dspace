<?php

### DB_READ_ONLY disables the admin console
define ( 'DB_READ_ONLY', false ) ;
#define ( 'DB_READ_ONLY', true ) ;

### MAINTENANCE_MODE redirects all requests to maintenance.html
#define ( 'MAINTENANCE_MODE', true ) ;


### SHOW_DEBUG echos various debug info to the bottom of the
### page and shouldn't ordinarily be used for production
define( 'SHOW_DEBUG', false ) ;








ini_set( 'include_path', ini_get( 'include_path' ) . ":./lib" ) ;

define( 'VERSION_LEVEL', 'production' ) ;
define( 'APPLICATION_BASE_DIR', '/data1/ir/htdocs/' ) ;
define( 'RDFAPI_INCLUDE_DIR', "./lib/rdfapi-php/api/" ) ;

define( 'RAP_DB_NAME', "uairrapmodel" ) ;
define( 'DEFAULT_RAP_MODEL', 'http://digitalcommons.library.arizona.edu/' ) ;
#define( 'RAP_DB_HOST', "db2.library.arizona.edu" ) ;

if( DB_READ_ONLY ) {
	define( 'RAP_DB_USER', "rouairuser" ) ;
	define( 'RAP_DB_PASS', "tF1wuy%WNO" ) ;
	define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@localhost/uairbackoffice' ) ;
	#define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@db2.library.arizona.edu/uairbackoffice' ) ;
} else {
	define( 'RAP_DB_USER', "irrapuser" ) ;
	define( 'RAP_DB_PASS', "RdfiaTsnk@(" ) ;
	define( 'APPLICATION_DSN', 'mysql://uairuser:tF1wuy%WNO@localhost/uairbackoffice' ) ;
	#define( 'APPLICATION_DSN', 'mysql://rouairuser:tF1wuy%WNO@db2.library.arizona.edu/uairbackoffice' ) ;
}





if( !defined( 'APPLICATION_PROTOCOL' )) {
	if( !empty( $_SERVER['HTTPS'] )) { define( 'APPLICATION_PROTOCOL', 'https' ) ; }
	else { define( 'APPLICATION_PROTOCOL', 'http' ) ; }
}

define( 'USE_CLEAN_URLS', true ) ;
if( USE_CLEAN_URLS ) {
	define( 'APPLICATION_BASE_HREF', APPLICATION_PROTOCOL.'://'.$_SERVER['SERVER_NAME'].'/' ) ;
	//changing this setting to http://digitalcommons.arizona.edu/ FIXES the about links and BREAKS journal addressing.  
	define( 'APPLICATION_URI', '' ) ;
	define( 'APPLICATION_INDEX_URI', '' ) ;
	define( 'APPLICATION_LOGIN_RESOURCE', 'https://digitalcommons.library.arizona.edu/util/login' ) ;
	define( 'ADMIN_LOGIN_RESOURCE', 'https://digitalcommons.library.arizona.edu/adminconsole/util/login' ) ;
	//define( 'APPLICATION_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/util/login' ) ;
	//define( 'ADMIN_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/adminconsole/util/login' ) ;
} else {
	define( 'APPLICATION_BASE_HREF', APPLICATION_PROTOCOL.'://'.$_SERVER['SERVER_NAME'].'/index.php' ) ;
	define( 'APPLICATION_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/index.php/util/login' ) ;
	define( 'ADMIN_LOGIN_RESOURCE', 'https://'.$_SERVER['SERVER_NAME'].'/index.php/adminconsole/util/login' ) ;
	define( 'APPLICATION_SESSION_TIMEOUT', 7200 ) ;
}


@include_once( 'recaptchalib.php' ) ;
define( 'RECAPTCHA_PUBLIC_KEY',  '6LexcAMAAAAAADepmbbnr0TrrMZEGK-r1s5ki_Mv' ) ;
define( 'RECAPTCHA_PRIVATE_KEY', '6LexcAMAAAAAAPVyWIUCvRomUxp95R9N7R4ZfLAT' ) ;

?>
